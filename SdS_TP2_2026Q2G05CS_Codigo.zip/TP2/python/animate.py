#!/usr/bin/env python3
"""Animacion de bandadas para tp2 (Vicsek/Votante) -- Fase 4 (VIZ-01, PLUS-02).

Modulo independiente de analyze.py: lanza sus propias corridas dedicadas de
`tp2` con trayectoria completa (--out), una por modelo, a rho=2 y con eta
elegido dentro del bracket de transicion orden-desorden que detecta
`sweep.py::explore_transition` para ese (model, rho) -- nunca un eta
hardcodeado. Cada trayectoria se renderiza como un GIF (PillowWriter, ffmpeg
no disponible en este entorno) donde cada particula es un vector de
velocidad coloreado por su angulo de heading via un colormap ciclico (hsv).

    python3 python/animate.py --selftest    # corre las verificaciones internas
    python3 python/animate.py               # genera ambos GIF (vicsek, voter)
"""

import argparse
import sys
from pathlib import Path

TP2_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(TP2_DIR / "python"))

import matplotlib
if "--show" not in sys.argv:
    matplotlib.use("Agg")
import matplotlib.animation as animation  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

from sweep import TP2_BIN, L_DEFAULT, RUN_TIMEOUT_S  # noqa: E402
from analyze import SWEEP_SUMMARY_CSV, load_summary, pick_eta_levels  # noqa: E402

ANIM_DATA_DIR = TP2_DIR / "data" / "animation"
PLOTS_DIR = TP2_DIR / "data" / "plots" / "animation"
RHO_CHARACTERISTIC = 2.0
STEPS_CHARACTERISTIC = 1000
SEED_CHARACTERISTIC = 1000  # constante explicita, distinta de cualquier semilla del barrido
ANGLE_CMAP = "hsv"
FRAME_STRIDE = 4
FPS = 20
def run_characteristic(model: str, eta: float, tag: str,
                        rho: float = RHO_CHARACTERISTIC,
                        steps: int = STEPS_CHARACTERISTIC) -> Path:
    """Corrida dedicada de trayectoria completa a (rho, eta), para animar.

    El eta llega desde afuera, elegido con `analyze.pick_eta_levels` sobre el
    barrido ya hecho -- o sea, del mismo va(eta) medido que alimenta las
    figuras, no de un mini-barrido aparte ni de un valor hardcodeado. Mismas
    convenciones de subprocess que sweep.py::run_one (lista de args,
    capture_output=True/text=True, nunca shell=True).
    """
    import subprocess

    ANIM_DATA_DIR.mkdir(parents=True, exist_ok=True)
    out_path = ANIM_DATA_DIR / f"{model}_rho{rho:g}_{tag}_traj.txt"

    args = [
        str(TP2_BIN),
        "--model", model,
        "--rho", f"{rho:.10g}",
        "--L", f"{L_DEFAULT:.10g}",
        "--eta", f"{eta:.10g}",
        "--steps", str(steps),
        "--seed", str(SEED_CHARACTERISTIC),
        "--out", str(out_path),
    ]
    try:
        proc = subprocess.run(args, capture_output=True, text=True, timeout=RUN_TIMEOUT_S)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"tp2 timeout (animate model={model}) tras {RUN_TIMEOUT_S}s"
        ) from exc
    if proc.returncode != 0:
        raise RuntimeError(f"tp2 fallo (animate model={model}): {proc.stderr.strip()}")
    return out_path


def read_trajectory(path) -> list[tuple[float, np.ndarray]]:
    """Parsea un archivo de trayectoria completa en frames (t, array Nx4).

    Formato auto-descriptivo (`writeTrajectoryFrame`, TP2/src/utils/io.cpp): una
    linea de 1 token es el `t` del proximo frame, cada linea de 4 tokens que le
    sigue es una fila `x y vx vy` de ese frame -- no hay ningun header ni conteo
    de N declarado, la distincion es puramente por cantidad de tokens por linea.
    """
    with open(path) as f:
        lines = [ln for ln in f.read().splitlines() if ln.strip()]

    frames: list[tuple[float, np.ndarray]] = []
    i = 0
    n = len(lines)
    while i < n:
        tokens = lines[i].split()
        if len(tokens) != 1:
            raise ValueError(f"esperaba una linea de 1 token (t) en la linea {i}: {lines[i]!r}")
        t = float(tokens[0])
        i += 1
        rows = []
        while i < n and len(lines[i].split()) == 4:
            rows.append([float(x) for x in lines[i].split()])
            i += 1
        frames.append((t, np.array(rows)))
    return frames


def render_animation(frames, out_path, L: float = L_DEFAULT, stride: int = FRAME_STRIDE,
                      fps: int = FPS, show: bool = False) -> None:
    """Renderiza `frames` como un GIF via PillowWriter (ffmpeg no disponible).

    Cada particula es un quiver de velocidad coloreado por su angulo de heading
    (atan2(vy, vx), siempre recomputado desde vx/vy -- el archivo de trayectoria
    nunca trae theta directamente). El angulo se normaliza sobre [-pi, pi] ->
    [0, 1] y el colormap ciclico usa clim=(0,1) FIJO en cada frame, nunca
    autoescalado, para que un color dado siempre signifique el mismo angulo a
    lo largo de toda la animacion.
    """
    sampled = frames[::stride]
    if not sampled:
        raise ValueError("render_animation: no hay frames para renderizar")

    # Figura cuadrada: la caja simulada es L x L, asi que con la relacion 4:3
    # que trae matplotlib por defecto la animacion quedaba con dos franjas
    # blancas a los costados y el sistema ocupando poco mas de la mitad del
    # cuadro. Cuadrada, el GIF llena el hueco que le deja la diapositiva.
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.set_xlim(0, L)
    ax.set_ylim(0, L)
    ax.set_aspect("equal")

    t0, rows0 = sampled[0]
    x, y, vx, vy = rows0[:, 0], rows0[:, 1], rows0[:, 2], rows0[:, 3]
    angle = np.arctan2(vy, vx)
    norm = (angle + np.pi) / (2.0 * np.pi)
    quiver = ax.quiver(x, y, vx, vy, norm, cmap=ANGLE_CMAP, clim=(0, 1), pivot="mid")
    title = ax.set_title(f"t = {t0:.1f}")

    def update(frame_index):
        t, rows = sampled[frame_index]
        x, y, vx, vy = rows[:, 0], rows[:, 1], rows[:, 2], rows[:, 3]
        angle = np.arctan2(vy, vx)
        norm = (angle + np.pi) / (2.0 * np.pi)
        quiver.set_offsets(np.column_stack([x, y]))
        quiver.set_UVC(vx, vy, norm)
        title.set_text(f"t = {t:.1f}")
        return quiver, title

    anim = animation.FuncAnimation(fig, update, frames=len(sampled), blit=False)
    anim.save(str(out_path), writer=animation.PillowWriter(fps=fps))
    if show:
        plt.show()
    plt.close(fig)


def _selftest():
    """Verificaciones internas -- convencion sin framework, analoga a sweep.py."""
    ANIM_DATA_DIR.mkdir(parents=True, exist_ok=True)
    synthetic_path = ANIM_DATA_DIR / "_selftest_synthetic.txt"
    synthetic_content = (
        "0.0\n1.0 2.0 0.03 0.0\n3.0 4.0 0.0 0.03\n"
        "1.0\n1.1 2.1 0.02 0.02\n3.1 4.1 -0.01 0.03\n"
    )
    synthetic_path.write_text(synthetic_content)
    try:
        frames = read_trajectory(synthetic_path)
        assert len(frames) == 2, f"esperados 2 frames, obtuvo {len(frames)}"

        t0, rows0 = frames[0]
        assert t0 == 0.0, f"frame 0: t esperado 0.0, obtuvo {t0}"
        expected0 = np.array([[1.0, 2.0, 0.03, 0.0], [3.0, 4.0, 0.0, 0.03]])
        assert np.array_equal(rows0, expected0), f"frame 0: filas inesperadas {rows0}"

        t1, rows1 = frames[1]
        assert t1 == 1.0, f"frame 1: t esperado 1.0, obtuvo {t1}"
        expected1 = np.array([[1.1, 2.1, 0.02, 0.02], [3.1, 4.1, -0.01, 0.03]])
        assert np.array_equal(rows1, expected1), f"frame 1: filas inesperadas {rows1}"
    finally:
        synthetic_path.unlink()

    print("animate.py selftest OK")


def main():
    parser = argparse.ArgumentParser(
        description="Animacion de bandadas (Vicsek/Votante), coloreada por angulo"
    )
    parser.add_argument("--selftest", action="store_true",
                        help="corre las verificaciones internas y sale")
    parser.add_argument("--show", action="store_true",
                        help="usa el backend interactivo de matplotlib en vez de Agg")
    args = parser.parse_args()

    if args.selftest:
        _selftest()
        return

    if not TP2_BIN.exists():
        sys.exit(f"error: no existe {TP2_BIN}. Correr `make` primero.")

    if not SWEEP_SUMMARY_CSV.exists():
        sys.exit(f"error: no existe {SWEEP_SUMMARY_CSV}. Correr python/sweep.py primero.")

    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    rows = load_summary(SWEEP_SUMMARY_CSV)

    # Dos situaciones caracteristicas por modelo, como pide el enunciado (a):
    # una claramente ordenada y una claramente desordenada. Los eta salen del
    # va(eta) ya medido, no de valores elegidos a ojo. El "ordenado" es el
    # mayor eta que todavia tiene va >= 0.9, o sea el borde ordenado de la
    # transicion: es ahi donde Vicsek muestra las bandas, no en eta ~ 0.
    for model in ("vicsek", "voter"):
        eta_low, _eta_mid, eta_high = pick_eta_levels(rows, model, RHO_CHARACTERISTIC)
        for tag, eta in (("ordenado", eta_low), ("desordenado", eta_high)):
            traj_path = run_characteristic(model, eta, tag)
            frames = read_trajectory(traj_path)
            out_path = PLOTS_DIR / f"animation_{model}_rho2_{tag}.gif"
            render_animation(frames, out_path, show=args.show)
            print(f"animacion: model={model} {tag} eta={eta:.4f} -> {out_path}")


if __name__ == "__main__":
    main()
